 /**
 *
 * Copyright 2023 by Guangzhou Easy EAI Technologny Co.,Ltd.
 * website: www.easy-eai.com
 *
 * Author: Jiehao.Zhong <zhongjiehao@easy-eai.com>
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * License file for more details.
 * 
 */

#ifndef JPEG_OPERATION_H
#define JPEG_OPERATION_H

#include <stdint.h>

#if defined(__cplusplus)
extern "C" {
#endif

extern uint32_t decode_JPEG_data(uint8_t *pOutData, uint8_t *pInData);
extern uint32_t encode_JPEG_data(uint8_t *pOutData, uint8_t *pPicData, uint16_t picWidth, uint16_t picHeight, int picFmt);

#if defined(__cplusplus)
}
#endif
#endif // JPEG_OPERATION_H