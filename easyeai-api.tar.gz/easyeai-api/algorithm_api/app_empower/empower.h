#ifndef EMPOWER_H
#define EMPOWER_H

#if defined(__cplusplus)
extern "C" {
#endif

extern void empower_EAIBOX();

#if defined(__cplusplus)
}
#endif

#endif
